import scipy.sparse as sp
import torch
import torch.nn.functional as F
import torch.nn as nn
import torch.nn.functional as F
from utils import *


# class DNN(nn.Module):
#     def __init__(self, nfeat, nhid, nclass, dropout):
#         super(DNN, self).__init__()
#         self.fcn1 = nn.Linear(nfeat, nhid)
#         self.fcn2 = nn.Linear(nhid, nclass)
#         self.dropout = dropout
#
#     def forward(self, x):
#         x = F.dropout(x, self.dropout, training=self.training)
#         x = self.fcn1(x)
#         #x1=x
#         x = F.dropout(x, self.dropout, training=self.training)
#         x = self.fcn2(x)
#         return F.log_softmax(x, dim=1), x


# class h_sigmoid(nn.Module):
#     def __init__(self, inplace=True):
#         super(h_sigmoid, self).__init__()
#         self.relu = nn.ReLU6(inplace=inplace)
#
#     def forward(self, x):
#         return self.relu(x + 3) / 6
#
# class h_swish(nn.Module):
#     def __init__(self, inplace=True):
#         super(h_swish, self).__init__()
#         self.sigmoid = h_sigmoid(inplace=inplace)
#
#     def forward(self, x):
#         return x * self.sigmoid(x)
#

import torch
import torch.nn as nn
import torch.nn.functional as F

import torch
import torch.nn as nn
import torch.nn.functional as F

k = 2 # Grid size
# inp_size = 5
# out_size = 7
# batch_size = 10
# X = torch.randn(batch_size, inp_size) # Our input
# linear = nn.Linear(inp_size*k, out_size)  # Weights
# repeated = X.unsqueeze(1).repeat(1,k,1)
# shifts = torch.linspace(-1, 1, k).reshape(1,k,1)
# shifted = repeated + shifts
# intermediate = torch.cat([shifted[:,:1,:], torch.relu(shifted[:,1:,:])], dim=1).flatten(1)
# outputs = linear(intermediate)

class SelfAttention(nn.Module):
    def __init__(self, nhid):
        super(SelfAttention, self).__init__()
        self.query = nn.Linear(nhid, nhid)
        self.key = nn.Linear(nhid, nhid)
        self.value = nn.Linear(nhid, nhid)

    def forward(self, x):
        Q = self.query(x)
        K = self.key(x)
        V = self.value(x)
        attention_scores = F.softmax(Q @ K.transpose(-2, -1) / (K.size(-1) ** 0.5), dim=-1)
        return attention_scores @ V

class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, dropout):
        super(ResidualBlock, self).__init__()
        self.bn1 = nn.BatchNorm1d(in_channels)

        self.linear = nn.Linear(in_channels * k, out_channels)  # Weights
        self.linear2 = nn.Linear(out_channels * k, out_channels)  # Weights
        # repeated = X.unsqueeze(1).repeat(1, k, 1)
        # shifts = torch.linspace(-1, 1, k).reshape(1, k, 1)
        # shifted = repeated + shifts
        # intermediate = torch.cat([shifted[:, :1, :], torch.relu(shifted[:, 1:, :])], dim=1).flatten(1)
        # self.outputs = linear(intermediate)


        self.fc1 = nn.Linear(in_channels, out_channels)
        self.bn2 = nn.BatchNorm1d(out_channels)
        self.fc2 = nn.Linear(out_channels, out_channels)
        self.dropout = dropout
        self.attention = SelfAttention(out_channels)  # 添加自注意力层
        if in_channels != out_channels:
            self.shortcut = nn.Linear(in_channels, out_channels)
        else:
            self.shortcut = nn.Identity()

    def forward(self, x):
        identity = self.shortcut(x)
        out = F.dropout(F.relu(self.bn1(x)), self.dropout, training=self.training)
        #out = self.fc1(out)

        #out=self.linear(out)
        repeated = out.unsqueeze(1).repeat(1, k, 1)
        shifts = torch.linspace(-1, 1, k).reshape(1, k, 1).to("cuda")
        shifted = repeated + shifts
        intermediate = torch.cat([shifted[:, :1, :], torch.relu(shifted[:, 1:, :])], dim=1).flatten(1)
        out = self.linear(intermediate)


        out = F.dropout(F.relu(self.bn2(out)), self.dropout, training=self.training)
        #out = self.fc2(out)

        repeated = out.unsqueeze(1).repeat(1, k, 1)
        shifts = torch.linspace(-1, 1, k).reshape(1, k, 1).to("cuda")
        shifted = repeated + shifts
        intermediate = torch.cat([shifted[:, :1, :], torch.relu(shifted[:, 1:, :])], dim=1).flatten(1)
        out = self.linear2(intermediate)
        out = self.attention(out)  # 应用自注意力机制
        out += identity  # Add input
        return out



class DNN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(DNN, self).__init__()
        self.block1 = ResidualBlock(nfeat, nhid, dropout)
        self.block2 = ResidualBlock(nhid, nclass, dropout)

    def forward(self, x):
        x = self.block1(x)
        x = F.relu(x)
        x = self.block2(x)
        return F.log_softmax(x, dim=1), x
# #
# class DNN(nn.Module):
#
#     def __init__(self, nfeat, nhid, nclass, dropout):
#         super(DNN, self).__init__()
#
#         # 添加批量标准化层
#         self.bn1 = nn.BatchNorm1d(nfeat)  # 假设nfeat是特征数量（即输入特征维度）
#
#         self.fcn1 = nn.Linear(nfeat, nhid)
#
#         # 在fcn1之后添加批量标准化层
#         self.bn2 = nn.BatchNorm1d(nhid)
#
#         self.fcn2 = nn.Linear(nhid, nclass)
#
#         self.dropout = nn.Dropout(p=dropout)  # 使用nn.Dropout包装dropout层
#         self.relu=h_swish()
#     def forward(self, x):
#         # 移除了对x的dropout（通常不在输入层之后直接应用dropout）
#
#         # 添加批量标准化
#         x = self.bn1(x)
#
#         # 添加ReLU激活函数（通常用于增加非线性）
#         x = F.relu(x)
#
#         # 添加dropout层
#         x = self.dropout(x)
#
#         x = self.fcn1(x)
#
#         # 再次添加批量标准化和ReLU
#         x = self.bn2(x)
#         x = F.relu(x)
#
#         # 再次添加dropout层
#         x = self.dropout(x)
#
#         x = self.fcn2(x)
#
#
#         # 输出log_softmax
#         return F.log_softmax(x, dim=1), x

    # 使用示例：


# 假设 nfeat=100, nhid=500, nclass=10, dropout=0.5
#model = DNN(nfeat=100, nhid=500, nclass=10, dropout=0.5)